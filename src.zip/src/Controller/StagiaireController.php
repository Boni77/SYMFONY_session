<?php

namespace App\Controller;

use App\Entity\Stagiaire;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class StagiaireController extends AbstractController
{
    /**
     * @Route("/stagiaire/{id}", name="app_stagiaire")
     */
    public function index(Stagiaire $stagiaire)
    {
        return $this->render('stagiaire/index.html.twig', [
            'stagiaire' => $stagiaire,
        ]);;
    }
}
